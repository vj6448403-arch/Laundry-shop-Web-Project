// JavaScript program to check whether a number is even or odd.

// Three variables used in the program.
let number = 0;
let resultMessage = "";
let isEven = false;

const numberInput = document.getElementById("numberInput");
const checkButton = document.getElementById("checkButton");
const result = document.getElementById("result");

checkButton.addEventListener("click", function () {
    // Get the number entered by the user.
    number = Number(numberInput.value);

    if (numberInput.value.trim() === "" || Number.isNaN(number)) {
        resultMessage = "Please enter a valid number.";
        result.textContent = resultMessage;
        console.log(resultMessage);
        return;
    }

    // Ternary operator determines whether the number is even or odd.
    isEven = number % 2 === 0;
    resultMessage = isEven
        ? "The number " + number + " is even."
        : "The number " + number + " is odd.";

    // Display the result and log it in the browser console.
    result.textContent = resultMessage;
    console.log(resultMessage);
});
