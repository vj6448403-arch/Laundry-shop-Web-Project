# JavaScript Task - Check if a Number is Even or Odd

## Objective
Create a JavaScript program that checks whether a given number is even or odd.

## Requirements covered
- JavaScript is linked correctly to the HTML.
- CSS is linked correctly to the HTML.
- Uses three JavaScript variables:
  1. `number`
  2. `resultMessage`
  3. `isEven`
- Uses a ternary operator to determine even/odd.
- Displays a message such as:
  - `The number 5 is odd.`
  - `The number 10 is even.`
- Logs the result using `console.log()`.
- No AI is used.
- Includes `index.html`, `style.css`, and `script.js`.

## How to run
1. Extract the ZIP file.
2. Open `index.html` in a web browser.
3. Enter a number.
4. Click **Check Number**.
5. The result appears on the page.
6. Open the browser Developer Tools Console to see the `console.log()` output.

## Files
- `index.html`
- `style.css`
- `script.js`
- `README.md`
